# SynQc hosted templates (generated)

This directory contains deployment and code templates to help you harden and ship a hosted version:

- `deploy/hosted/` — Nginx edge + oauth2-proxy + Postgres + Redis
- `docs/Hosted_Deployment_Reference.md` — architecture and operational notes
- `scripts/generate_hosted_secrets.py` — generates cookie secret + master key
- `backend/synqc_backend/hosted/` — optional FastAPI helpers (auth + middleware)
- `.github/workflows/release-images.yml` — CI skeleton to publish container images to GHCR

Copy these into your repo and adapt as needed.
