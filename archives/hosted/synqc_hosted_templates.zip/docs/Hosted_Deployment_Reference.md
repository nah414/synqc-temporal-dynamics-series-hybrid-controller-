# Hosted Deployment Reference (Same-Origin UI + /api)

This is a **hosted-first** reference architecture for SynQc TDS that:

- Serves the **web UI** and the **API** from the **same origin** (so the browser never needs CORS).
- Protects both UI + API behind a standard login (OIDC) using **oauth2-proxy**.
- Runs the SynQc **API** and **worker** privately on an internal network.
- Uses **PostgreSQL** for durable state and **Redis** for the queue.

This folder is intended to be copied into the repo as a starting point:
`deploy/hosted/…` + `docs/Hosted_Deployment_Reference.md`.

---

## 1) Architecture at a glance

### Components

1) **Edge (Nginx)**
- Public entrypoint (ports 80/443)
- Serves `/` (static UI)
- Proxies `/api/*` to the internal API service
- Performs auth checks by calling `oauth2-proxy` (Nginx `auth_request`)

2) **oauth2-proxy**
- Handles OIDC login (Google / Auth0 / Okta / Keycloak / etc.)
- Issues a secure, httpOnly session cookie
- When Nginx calls `/oauth2/auth`, oauth2-proxy replies with:
  - 202 (authorized) + headers such as `X-Auth-Request-User`, `X-Auth-Request-Email`
  - or 401 (unauthorized)

3) **synqc-api**
- FastAPI service that exposes endpoints like:
  - POST `/experiments/run`
  - GET `/experiments/recent`
  - GET `/experiments/{id}`
  - GET `/hardware/targets`
  - GET `/health`
- In hosted mode, you should require auth and (optionally) trust identity headers from the reverse proxy.

4) **synqc-worker**
- Background worker consuming the Redis queue and executing jobs (simulator/hardware).
- Writes results to Postgres.

5) **PostgreSQL**
- Stores experiments, job states, users/orgs, provider connections, etc.

6) **Redis**
- Queue + ephemeral state.

### Request flow

Browser → **Nginx** → (auth_request) → **oauth2-proxy**  
If authorized:  
- UI: Nginx serves `/index.html`  
- API: Nginx proxies `/api/…` → **synqc-api** (internal)

Worker path:  
synqc-worker ↔ Redis  
synqc-worker ↔ Postgres  
synqc-api ↔ Redis/Postgres

---

## 2) Why same-origin `/api` matters

Your current UI supports a `?api=http://localhost:8001` override. In hosted mode, you want users to just visit:

`https://yourdomain.example/`

and have the UI automatically call:

`https://yourdomain.example/api/...`

This avoids:
- CORS configuration complexity
- token leakage across origins
- dev/prod mismatch

This reference uses Nginx to add the `/api/` prefix externally and **strip it** before forwarding to the internal API, so you **do not have to change** the backend routes immediately.

---

## 3) Docker Compose (single VM) — MVP hosted stack

### Files

- `deploy/hosted/docker-compose.hosted.yml`
- `deploy/hosted/.env.hosted.example`
- `deploy/hosted/nginx/nginx.conf`
- `deploy/hosted/nginx/Dockerfile`

### Quick start steps

1) Copy these files into the repo:
```
deploy/hosted/...
docs/Hosted_Deployment_Reference.md
```

2) Create a real `.env.hosted` from the example:
```
cp deploy/hosted/.env.hosted.example deploy/hosted/.env.hosted
```

3) Generate secrets (cookie secret + master key):
```
python scripts/generate_hosted_secrets.py
```
Paste the printed values into `deploy/hosted/.env.hosted`.

4) Start the stack:
```
docker compose -f deploy/hosted/docker-compose.hosted.yml --env-file deploy/hosted/.env.hosted up -d --build
```

5) Visit:
- http://localhost/ (or your server domain)

### Notes
- For real production, put TLS termination in front (Cloudflare / ALB / Caddy / Traefik / Nginx with certs).
- If you terminate TLS upstream, ensure Nginx receives `X-Forwarded-Proto=https` and sets Secure cookies.

---

## 4) Auth provider options (recommended)

### Option A: Managed auth (Auth0/Okta/Google)
- Best for consumer-grade UX
- oauth2-proxy connects to your provider via OIDC
- Minimal app code required

### Option B: Self-hosted Keycloak (staging only)
- Good for dev/staging
- Not recommended to run inside the same compose as your app for serious production unless you know what you're doing.

---

## 5) Secrets management guidance

This reference uses environment variables for simplicity.

For production:
- **Do not** keep `.env.hosted` in git.
- Use one of:
  - Cloud secret manager (AWS Secrets Manager / SSM, GCP Secret Manager, Azure Key Vault)
  - Kubernetes Secrets + KMS encryption at rest
  - HashiCorp Vault

Provider credentials (BYOC) should be encrypted at rest:
- MVP: application-level encryption (Fernet) using `SYNQC_MASTER_KEY`
- Later: envelope encryption using KMS + per-record data keys

---

## 6) Production hardening checklist

- Only the edge proxy is public; API/worker/redis/postgres are private.
- Disable public `/docs` in production or require auth.
- Enforce request size limits (413 for large requests).
- Add rate limits (IP + user-based).
- Add budgets/quotas for shots and remote hardware.
- Log with request IDs; never log secrets or Authorization headers.
- Set security headers (CSP, HSTS, X-Frame-Options, etc.).

---

## 7) Kubernetes reference (optional)

If/when you want Kubernetes:
- Use a managed Postgres and managed Redis.
- Deploy API and worker separately.
- Use Ingress for TLS and route `/api` to API service.
- Run oauth2-proxy as a sidecar or separate deployment.
- Use NetworkPolicies to prevent the world from reaching the API directly.

A minimal manifest skeleton is included under:
`deploy/hosted/k8s/`

