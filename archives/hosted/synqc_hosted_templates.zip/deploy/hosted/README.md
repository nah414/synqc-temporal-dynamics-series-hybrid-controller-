# Hosted deployment (Docker Compose)

This folder contains a hosted-first Docker Compose stack:

- Nginx edge serves the static UI and proxies `/api/*` to the backend.
- oauth2-proxy handles OIDC login and issues a secure cookie.
- API and worker are private (no public ports).
- Postgres + Redis are included for MVP deployments.

## Quick start

```bash
cp deploy/hosted/.env.hosted.example deploy/hosted/.env.hosted
python scripts/generate_hosted_secrets.py
# paste secrets into deploy/hosted/.env.hosted

docker compose -f deploy/hosted/docker-compose.hosted.yml --env-file deploy/hosted/.env.hosted up -d --build
```

Open:
- http://localhost/

## Production notes

- Put TLS in front (Cloudflare / ALB / etc.) and set `OAUTH2_PROXY_COOKIE_SECURE=true`.
- Pin image tags (`vX.Y.Z`) instead of `latest`.
- Move Postgres/Redis to managed services once you have real users.
