# Kubernetes skeleton (optional)

These manifests are intentionally minimal and are not intended to be a complete production setup.

Recommended production posture:
- Managed Postgres + managed Redis (do not run stateful DBs in-cluster unless you must)
- TLS terminated at the Ingress / Load Balancer
- oauth2-proxy integrated with ingress-nginx (external auth) OR use an identity-aware proxy (Cloudflare Access)
- NetworkPolicies to restrict pod-to-pod traffic

Files:
- namespace.yaml
- web.yaml (static UI)
- api.yaml
- worker.yaml
- oauth2-proxy.yaml
- ingress.yaml (ingress-nginx style annotations for oauth2-proxy)

You will need to create Kubernetes Secrets for:
- POSTGRES_PASSWORD
- REDIS_PASSWORD
- SYNQC_MASTER_KEY
- OAUTH2_PROXY_COOKIE_SECRET
- OAUTH2_PROXY_CLIENT_SECRET
