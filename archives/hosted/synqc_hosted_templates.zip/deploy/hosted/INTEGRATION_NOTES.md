# Integration notes (hosted)

This repo includes *templates* under `backend/synqc_backend/hosted/` and `deploy/hosted/`.
You still need to wire them into the existing codebase.

## 1) UI: make API calls same-origin

Update the UI fetch base URL logic so hosted deployments default to `/api`.

Desired behavior:
- If `?api=` is provided, use it.
- Else if running on http(s), use `${window.location.origin}/api`.
- Else (file://), default to `http://localhost:8001` for local-first usage.

## 2) API: require auth (hosted)

In your FastAPI app wiring (likely `synqc_backend/api.py`), add:

```python
from synqc_backend.hosted.middleware import RequestIdMiddleware, MaxRequestSizeMiddleware
from synqc_backend.hosted.auth import require_principal
from fastapi import Depends

app.add_middleware(RequestIdMiddleware)
app.add_middleware(MaxRequestSizeMiddleware)

@app.get("/me")
def me(p=Depends(require_principal)):
    return {"user": p.user, "email": p.email}
```

Then apply `Depends(require_principal)` to any routes that should require login.

SECURITY CRITICAL:
- Do NOT expose synqc-api directly to the internet.
- Only Nginx (synqc-edge) should be able to reach it.

## 3) Worker: no inbound ports

Worker should not publish ports. It should only connect outbound to:
- Redis
- Postgres
- provider APIs

## 4) Deployment

Use `deploy/hosted/docker-compose.hosted.yml` as the MVP hosted stack.
