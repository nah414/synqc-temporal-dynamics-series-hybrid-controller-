"""Hosted-mode middleware helpers.

These are optional. If you already set limits/headers at the edge proxy,
you may not need these. They can still provide defense-in-depth.

- Request size limit (reject huge requests early)
- Add a request-id if missing
"""

from __future__ import annotations

import os
import uuid
from typing import Callable, Optional

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp


def _int_env(name: str, default: int) -> int:
    raw = os.getenv(name)
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


class RequestIdMiddleware(BaseHTTPMiddleware):
    header_name: str = "X-Request-ID"

    async def dispatch(self, request: Request, call_next: Callable):
        rid = request.headers.get(self.header_name) or str(uuid.uuid4())
        response: Response = await call_next(request)
        response.headers[self.header_name] = rid
        return response


class MaxRequestSizeMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp, max_bytes: Optional[int] = None):
        super().__init__(app)
        self.max_bytes = max_bytes if max_bytes is not None else _int_env("SYNQC_MAX_REQUEST_BYTES", 1048576)

    async def dispatch(self, request: Request, call_next: Callable):
        cl = request.headers.get("content-length")
        if cl is not None:
            try:
                if int(cl) > self.max_bytes:
                    return Response(content="Request too large", status_code=413)
            except ValueError:
                pass
        return await call_next(request)
