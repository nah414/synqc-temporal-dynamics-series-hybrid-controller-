"""Hosted-mode helpers (oauth2-proxy / reverse-proxy integration).

Goal:
- In hosted deployments, Nginx + oauth2-proxy authenticate users.
- Nginx forwards identity headers to the API.
- The API trusts these headers **only** when it is not publicly reachable
  (i.e., only the edge proxy can reach it).

This module provides a minimal FastAPI dependency you can wire into endpoints.

Suggested header names (from Nginx config in deploy/hosted/nginx/nginx.conf):
- X-Auth-Request-Email
- X-Auth-Request-User
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from fastapi import Depends, HTTPException, Request, status


@dataclass(frozen=True)
class Principal:
    user: str
    email: Optional[str] = None


def get_principal_from_oauth2_proxy_headers(request: Request) -> Principal:
    # These are set by Nginx when auth_request succeeds.
    user = request.headers.get("X-Auth-Request-User") or request.headers.get("X-Forwarded-User")
    email = request.headers.get("X-Auth-Request-Email") or request.headers.get("X-Forwarded-Email")

    if not user and not email:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated (missing oauth2-proxy headers).",
        )

    return Principal(user=user or email or "unknown", email=email)


def require_principal(request: Request) -> Principal:
    """Minimal auth guard for hosted mode.

    IMPORTANT SECURITY REQUIREMENT:
    - Your API service must NOT be reachable directly from the Internet.
      Otherwise attackers can spoof these headers.
    - Only your reverse proxy should be able to connect to the API.
    """
    return get_principal_from_oauth2_proxy_headers(request)


# Example dependency usage:
#   @app.get("/me")
#   def me(p: Principal = Depends(require_principal)):
#       return {"user": p.user, "email": p.email}
