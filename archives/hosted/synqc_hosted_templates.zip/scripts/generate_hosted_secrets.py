#!/usr/bin/env python3
"""Generate secrets for hosted deployment.

This prints:
- SYNQC_MASTER_KEY (Fernet-compatible, urlsafe base64)
- OAUTH2_PROXY_COOKIE_SECRET (base64)

Usage:
  python scripts/generate_hosted_secrets.py
"""
from __future__ import annotations

import base64
import secrets


def gen_fernet_key() -> str:
    # Fernet expects 32 urlsafe-base64-encoded bytes.
    raw = secrets.token_bytes(32)
    return base64.urlsafe_b64encode(raw).decode("ascii")


def gen_cookie_secret() -> str:
    # oauth2-proxy cookie secret: 16/24/32 bytes, base64 encoded.
    raw = secrets.token_bytes(32)
    return base64.b64encode(raw).decode("ascii")


if __name__ == "__main__":
    master_key = gen_fernet_key()
    cookie_secret = gen_cookie_secret()

    print("=== Generated secrets ===")
    print(f"SYNQC_MASTER_KEY={master_key}")
    print(f"OAUTH2_PROXY_COOKIE_SECRET={cookie_secret}")
    print()
    print("Paste these into deploy/hosted/.env.hosted (DO NOT commit that file).")
