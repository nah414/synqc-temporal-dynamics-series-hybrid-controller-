# SynQc Shor / RSA Demo Add‑On

This add‑on drops a **Shor’s Algorithm (toy RSA)** panel into the SynQc Temporal Dynamics Series (TDS) console UI (the large empty console area you circled), and exposes matching backend endpoints.

A key point: **Shor doesn’t “encrypt/decrypt”** — it **factors** the RSA modulus `N = p·q`. Once you have `p` and `q`, you can compute the RSA private exponent `d` and then decrypt.  
This feature is implemented as a **separate module** (feature‑flagged) so it won’t interfere with the existing temporal dynamics workflows unless you use it.

## What you get

### Front end
- A panel (pure HTML/CSS/JS, no framework assumptions) that mounts into a host `<div>` you place in the console area.
- Controls for:
  - Generate a **toy RSA** keypair (small bit sizes only)
  - Encrypt (RSA)
  - Decrypt **via factoring** (Shor if available, otherwise classical fallback)
  - Factor `N` directly
- Output area with structured results + timing.

### Back end
- A FastAPI router you can mount under: `GET/POST /api/shor/*`
- Endpoints:
  - `POST /api/shor/factor` → factor `N` (auto/qiskit/classical; aer/ibm)
  - `POST /api/shor/estimate` → heuristic resource estimate (qubits + scaling notes)
  - `POST /api/shor/rsa/generate` → generate toy RSA keypair
  - `POST /api/shor/rsa/encrypt` → encrypt integer or short UTF‑8 text
  - `POST /api/shor/rsa/decrypt` → decrypt using recovered private key (factors `N`)
  - `GET /api/shor/runs` → recent run summaries (so you can populate "Experiment Runs")
  - `GET /api/shor/runs/{run_id}` → full run record
- Optional use of **Qiskit’s Shor implementation** when Qiskit is installed.
- Hard safety limits (bit‑length caps) so this stays a **demo** and not a real crypto‑breaking tool.

## Files

```
synqc_shor_addon/
  backend/
    synqc_shor/
      __init__.py
      api.py
      estimate.py
      factor.py
      run_store.py
      rsa.py
      qiskit_shor.py
      classical_factor.py
      config.py
    tests/
      test_rsa_roundtrip.py
  frontend/
    shor-panel.css
    shor-panel.js
    shor-panel.html   # copy/paste snippet
  INTEGRATION_NOTES.md
```

## Backend integration (FastAPI)

1) Copy `backend/synqc_shor/` into your backend source tree (or add it as a package).

2) Install requirements (minimum):

```bash
pip install fastapi pydantic
```

Optional (for Qiskit Shor support):

```bash
pip install qiskit qiskit-aer qiskit-ibm-runtime qiskit-algorithms
```

3) Mount the router in your FastAPI app (your file might be `main.py`, `app.py`, etc.):

```python
from synqc_shor.api import router as shor_router

app.include_router(shor_router, prefix="/api/shor", tags=["shor"])
```

4) (If needed) allow your front end origin via CORS, same as your other endpoints.

5) Run your backend on the same port the UI expects (your screenshot showed `http://localhost:8001`).

## Frontend integration

1) In the **console content area you circled**, add a mount point:

```html
<div id="shor-panel-host"></div>
```

2) Include the CSS + JS (or import them via your build system):

```html
<link rel="stylesheet" href="./shor-panel.css" />
<script type="module" src="./shor-panel.js"></script>
```

3) The JS auto-mounts into `#shor-panel-host` (and safely does nothing if it doesn’t exist).

## Safety / guardrails

- This module **rejects large RSA moduli** by default (`SYNQC_SHOR_MAX_N_BITS`, default 20).
- This is strictly a **toy demonstration**: current quantum hardware cannot break real RSA keys.
- If you *really* want to raise the limit for experiments, do it intentionally and accept the compute cost.

## Optional run logging + step timings

These are the knobs that make the feature feel "native" inside SynQc:

- `SYNQC_SHOR_INCLUDE_STEPS=1` (default) adds a `steps` field to responses so you can render a temporal sequence/timeline.
- `SYNQC_SHOR_RUN_LOG_MAX=200` controls the in-memory run buffer for `GET /api/shor/runs`.
- `SYNQC_SHOR_RUN_LOG_PATH=/path/to/file.jsonl` appends JSONL run records to disk (optional).

## Running tests

```bash
pytest backend/tests -q
```
